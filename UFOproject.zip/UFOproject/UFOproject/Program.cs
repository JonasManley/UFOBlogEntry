﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Diagnostics;

namespace UFOproject
{
    class Program
    {
        static void Main(string[] args)
        {


            //Hashtable hashtable = new Hashtable();
            //hashtable[1] = "One";
            //hashtable[2] = "Two";
            //hashtable[13] = "Thirteen";

            //Console.WriteLine("Hash");
            //stopwatch.Start();
            //var searchHash = hashtable[1];
            //stopwatch.Stop();
            //Console.WriteLine($"Time elapsed: {stopwatch.Elapsed}");


            //Forsøg #1 --------------------
            //Stopwatch stopwatch = new Stopwatch();

            //Console.WriteLine("Dictionary");
            //Dictionary<int, string> dictionary = new Dictionary<int, string>() { { 1, "One" }, { 2, "Two" }, { 13, "Thirteen" } };
            //stopwatch.Start();
            //var searchDic = dictionary[1];
            //stopwatch.Stop();
            //Console.WriteLine($"Time elapsed: {stopwatch.Elapsed}");

            //stopwatch.Reset();

            //Console.WriteLine("List");
            ////List<int> list = new List<int>() { 1, 2, 3, 4, 5, 6};
            //List<string> list = new List<string>() 
            //{
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk100",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk200",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk300",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk10",
            //    "jonas", "jonas", "jonas", "jonas", "dunk5", "jonas", "jonas", "jonas", "jonas", "dunk400"
            //};

            //List<int> list = autoList(100000);
            //stopwatch.Start();
            //var searchList = list[5];
            //stopwatch.Stop();
            //Console.WriteLine($"Time elapsed: {stopwatch.Elapsed}");

            //Forsøg #1 SLUT --------------------

            //stopwatch.Reset();

            //Console.WriteLine("Foreach over the list");
            //stopwatch.Start();
            //foreach (var item in list)
            //{
            //    if (item == "dunk200")
            //    {
            //        stopwatch.Stop();
            //        Console.WriteLine($"Time elapsed: {stopwatch.Elapsed}");
            //    }
            //}



            // ----------------------------------------------------------------------------------------------------------------------


            Stopwatch stopwatch = new Stopwatch();

            //Console.WriteLine("Dictionary");
            Dictionary<int, string> dictionary = new Dictionary<int, string>() { 
             { 1,  "One" }, { 2,  "Two" }, { 3,  "Two" }, { 4,  "Two" }, { 5,  "Two" }, { 6,  "Two" }, { 7,  "Two" }, { 8,  "Two" },{ 9,  "Two" },  { 10, "Two" },  
             { 11, "Two" }, { 12, "Two" }, { 13, "Two" }, { 14, "Two" }, { 15, "Two" }, { 16, "Two" }, { 17, "Two" }, { 18, "Two" },{ 19, "Two" },  { 20, "two" },
             { 21, "One" }, { 22, "Two" }, { 23, "Two" }, { 24, "Two" }, { 25, "Two" }, { 26, "Two" }, { 27, "Two" }, { 28, "Two" },{ 29, "Two" },  { 30, "Two" },
             { 31, "One" }, { 32, "Two" }, { 33, "Two" }, { 34, "Two" }, { 35, "Two" }, { 36, "Two" }, { 37, "Two" }, { 38, "Two" },{ 39, "Two" },  { 40, "Two" },
             { 41, "One" }, { 42, "Two" }, { 43, "Two" }, { 44, "Two" }, { 45, "Two" }, { 46, "Two" }, { 47, "Two" }, { 48, "Two" },{ 49, "Two" },  { 50, "Two" },
             { 51, "One" }, { 52, "Two" }, { 53, "Two" }, { 54, "Two" }, { 55, "Two" }, { 56, "Two" }, { 57, "Two" }, { 58, "Two" },{ 59, "Two" },  { 60, "Two" },
             { 61, "One" }, { 62, "Two" }, { 63, "Two" }, { 64, "Two" }, { 65, "Two" }, { 66, "Two" }, { 67, "Two" }, { 68, "Two" },{ 69, "Two" },  { 70, "Two" },
             { 71, "One" }, { 72, "Two" }, { 73, "Two" }, { 74, "Two" }, { 75, "Two" }, { 76, "Two" }, { 77, "Two" }, { 78, "Two" },{ 79, "Two" },  { 80, "Two" },
             { 81, "One" }, { 82, "Two" }, { 83, "Two" }, { 84, "Two" }, { 85, "Two" }, { 86, "Two" }, { 87, "Two" }, { 88, "Two" },{ 89, "Two" },  { 90, "Two" },
             { 91, "One" }, { 92, "Two" }, { 93, "Two" }, { 94, "Two" }, { 95, "Two" }, { 96, "Two" }, { 97, "Two" }, { 98, "Two" },{ 99, "Two" },  { 100, "Two"},
             { 101, "One"}, { 102, "Two"}, { 103, "Two"}, { 104, "Two"}, { 105, "Two"}, { 106, "Two"}, { 107, "Two"}, { 108, "Two"},{ 109, "Two"},  { 110, "Two"},};
            stopwatch.Start();
            var searchDic = dictionary[1];
            stopwatch.Stop();
            Console.WriteLine($"Time elapsed: {stopwatch.Elapsed}");



            //Stopwatch stopwatch = new Stopwatch();

            //Console.WriteLine("Foreach over the list");
            stopwatch.Start();
            foreach (var item in dictionary)
            {
                if (item.Key == 10)
                {
                    stopwatch.Stop();
                    Console.WriteLine($"Time elapsed: {stopwatch.Elapsed}");
                }
            }




            Console.ReadLine();
        }
        public static List<int> autoList(int numberOfElements)
        {
            List<int> generatedList = new List<int>();
            for (int i = 0; i < numberOfElements; i++)
            {
                generatedList.Add(i);
            }
            return generatedList;
        }
    }
}


